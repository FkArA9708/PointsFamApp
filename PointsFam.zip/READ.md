# Wachtwoorden voor alle gebruikers

## KIND GEBRUIKERS

1. Gebruikersnaam: kind1, wachtwoord: kind123, rol: kind, familieA
2. Gebruikersnaam: kind2, wachtwoord: kind123, rol: kind, familieA
3. Gebruikersnaam: kind3, wachtwoord: kind456, rol: kind, familieB

## OUDER GEBRUIKERS

1. Gebruikersnaam: ouder1, wachtwoord: ouder123, rol: ouder, familieA
2. Gebruikersnaam: ouder2, wachtwoord: ouder123, rol: ouder, familieA
3. Gebruikersnaam: ouder3, wachtwoord: ouder456, rol: ouder, familieB

heb gebruik gemaakt van node.js, express.js, javascript, html, css en json voor deze project

